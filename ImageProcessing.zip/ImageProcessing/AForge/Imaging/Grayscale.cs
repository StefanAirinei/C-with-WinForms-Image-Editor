﻿namespace AForge.Imaging
{
	internal class Grayscale : Filters.Grayscale
	{
		public Grayscale(double cr, double cg, double cb) : base(cr, cg, cb)
		{
		}
	}
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcessing
{
	public partial class OverlayPicturesForm : Form
	{
		Form1 mainForm = null;

		public OverlayPicturesForm()
		{
			InitializeComponent();
		}
		  
		public OverlayPicturesForm(Form1 frm)
		{
			InitializeComponent();
			mainForm = frm;
		}

		private void importMaskButton_Click(object sender, EventArgs e)
		{
			EditClass.ImportMaskPicture(pictureBox1);
		}
		  
		private void overlayButton_Click(object sender, EventArgs e)
		{
			mainForm.pictureBox2.Image = EditClass.overlayPicture((Bitmap)mainForm.pictureBox2.Image, (Bitmap)pictureBox1.Image);
		}

		private void adjustRename_Click(object sender, EventArgs e)
		{
			
		}
	}
}

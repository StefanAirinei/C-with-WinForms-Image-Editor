﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcessing
{
	class ControlClass
	{
		public static void displayPanel()
		{  
			//container
		}

		public static void openChildForm(Form childForm, Form activeForm, Panel mainPanel)    ////incarc o noua forma in main panel ul ala
		{
			if (activeForm != null)
				activeForm.Close();

			activeForm = childForm;
			childForm.TopLevel = false;
			childForm.FormBorderStyle = FormBorderStyle.None;
			childForm.Dock = DockStyle.Fill;
			mainPanel.Controls.Add(childForm);
			mainPanel.Tag = childForm;
			childForm.BringToFront();
			childForm.Show();
		}

		public static void closeChildForm(Form childForm, Form activeForm, Panel mainPanel)
		{
			if (activeForm != null)
				activeForm.Close();

			activeForm = childForm;
			childForm.Hide();
		}

		public static Bitmap reset(Bitmap originalBMP, Bitmap seconBMP)
		{
			unsafe
			{
				BitmapData bitmapData = originalBMP.LockBits(new Rectangle(0, 0, originalBMP.Width, originalBMP.Height), ImageLockMode.ReadWrite, originalBMP.PixelFormat);
				BitmapData bitmapDataSecond = seconBMP.LockBits(new Rectangle(0, 0, seconBMP.Width, seconBMP.Height), ImageLockMode.ReadWrite, seconBMP.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(originalBMP.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;
				byte* FirstPixelSecondImg = (byte*)bitmapDataSecond.Scan0;

				for (int y = 0; y < heightInPixels; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);
					byte* currentLineSecondImg = FirstPixelSecondImg + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						currentLineSecondImg = currentLine;
					}
				}

				originalBMP.UnlockBits(bitmapData);
				seconBMP.UnlockBits(bitmapDataSecond);
			}

			return seconBMP;
		}
	}
}

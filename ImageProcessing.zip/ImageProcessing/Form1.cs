﻿using Emgu.CV;
using Emgu.CV.Structure;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcessing
{
	public partial class Form1 : Form
	{
		private Form activeForm = null;
		Point point;

		public Form1()
		{
			InitializeComponent();
			customizePanels();
		}

		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private void customizePanels()
		{
			filtresSubmenuPanel.Visible = false;
			FilePanel.Visible = false;
		}

		private void hidePanels()
		{
			if (filtresSubmenuPanel.Visible == true)
				filtresSubmenuPanel.Visible = false;
			if (FilePanel.Visible == true)
				FilePanel.Visible = false;
		}

		private void Import_Click(object sender, EventArgs e)
		{
			//ControlClass.openChildForm(imageSuportForm, activeForm, mainPanel);
			MainMenuClass.applyImportImage(pictureBox1, pictureBox2, pictureBox3, pictureBox4);
		}

		private void MedianAlike_Click(object sender, EventArgs e)   ////asta e similar cu filtrul median dar foloseste un filtru aplicat in coltul dreapta jos al fiearui pixel ca n am stiut sa retin o copie a pixelilor deja parcursi
		{
			//pictureBox2.Image = EditClass.overlayPicture((Bitmap)pictureBox2.Image, overlayPicturesForm.pictureBoxMask);
			pictureBox2.Image = EditClass.applyMedianAlikeFiltre((Bitmap)pictureBox1.Image);
		}

		private void SlowMedianFiltre_Click(object sender, EventArgs e)
		{
			pictureBox2.Image = EditClass.applySlowMedianFiltre((Bitmap)pictureBox1.Image);
		}

		private void NegativeFiltre_Click(object sender, EventArgs e)
		{
			pictureBox2.Image = EditClass.applyFiltre((Bitmap)pictureBox1.Image);
		}

		public void RGB(byte val, int rgbIndex)
		{
			pictureBox2.Image = EditClass.setRGBColor((Bitmap)pictureBox1.Image, rgbIndex, val);
		}

		public void changeBrightness(int val, int trackIndex)
		{
			if (trackIndex == 1)
				pictureBox1.Image = EditClass.setGrayscaleBrightness((Bitmap)pictureBox1.Image, trackIndex, val);

			if (trackIndex == 2)
				pictureBox2.Image = EditClass.setGrayscaleBrightness((Bitmap)pictureBox2.Image, trackIndex, val);

			if (trackIndex == 3)
				pictureBox3.Image = EditClass.setGrayscaleBrightness((Bitmap)pictureBox3.Image, trackIndex, val);

			if (trackIndex == 4)
				pictureBox4.Image = EditClass.setGrayscaleBrightness((Bitmap)pictureBox4.Image, trackIndex, val);
		}

		private void displayPanel(Panel panel)
		{
			if (panel.Visible == false)
			{
				hidePanels();
				panel.Visible = true;
			}
			else panel.Visible = false;
		}

		private void DisplayRGBPanel_Click(object sender, EventArgs e)
		{
			rgbControll_Form = new RGBControll_Form(this);
			ControlClass.openChildForm(rgbControll_Form, activeForm, bottomPanel);
		}

		private void DisplayFiltresPanel_Click(object sender, EventArgs e)
		{
			displayPanel(filtresSubmenuPanel);
		}

		private void DisplayFilePanel_Click(object sender, EventArgs e)
		{
			displayPanel(FilePanel);
		}

		private void DisplayHomePanel_Click(object sender, EventArgs e)
		{
			//ControlClass.closeChildForm(, activeForm, mainPanel);
		}

		private void buttonMainWorkSpace_Click(object sender, EventArgs e)
		{
			//ControlClass.openChildForm(imageSuportForm, activeForm, mainPanel);
		}

		private void mainPanel_MouseMove(object sender, MouseEventArgs e)
		{
			//int btnHeight = button4.Size.Height;
			//int btnWidth = button4.Size.Width;
			//
			//Point currentPoint = Control.MousePosition;
			//
			//if (currentPoint.X - button4.Location.X < 200 && currentPoint.X - button4.Location.X > 0)
			//button4.Location = new Point(button4.Location.X + 1, button4.Location.Y);
		}

		private void OverlaySegments_Click(object sender, EventArgs e)
		{ 
			pictureBox2.Image = EditClass.applyOverlaySegments((Bitmap)pictureBox1.Image);
		}

		private void Fourier_Filtre(object sender, EventArgs e)
		{
			pictureBox2.Image = EditClass.applyFourierTransform((Bitmap)pictureBox1.Image);
		}

		private void OverlayPicture_Click(object sender, EventArgs e)
		{
			overlayPicture_Form = new OverlayPicturesForm(this);
			ControlClass.openChildForm(overlayPicture_Form, activeForm, bottomPanel);
			//pictureBox2.Image = EditClass.overlayPicture((Bitmap)pictureBox2.Image, (Bitmap)auxMaskPicBox.Image);
		}
		
		private void ImportMaskPic_Click(object sender, EventArgs e)
		{
			EditClass.ImportMaskPicture(auxMaskPicBox);
		}

		private void reset_Click(object sender, EventArgs e)
		{
			pictureBox2.Image = null;
			//pictureBox2.Image = new Bitmap(pictureBox1.Image);              // (Bitmap)ControlClass.reset((Bitmap)pictureBox1.Image, (Bitmap)pictureBox2.Image);
			//pictureBox2.Refresh();
		}

		private void LaPlace_Click(object sender, EventArgs e)
		{
			pictureBox2.Image = EditClass.applyLaPlaceFiltre((Bitmap)pictureBox2.Image);
		}

		private void adjustMask_Click(object sender, MouseEventArgs e)
		{
			this.Cursor = new Cursor(Cursor.Current.Handle);

			int xCoordinate = Cursor.Position.X;
			int yCoordinate = Cursor.Position.Y; 
			
			MessageBox.Show("coords: " + xCoordinate + " " + yCoordinate + "   coords e: " + e.X + " " + e.Y);
		}

		private void pictureBox2_MouseClick(object sender, MouseEventArgs e)
		{   
			point = new Point(e.X, e.Y);
			 
			pictureBox2.Size = new Size((int)pictureBox2.Image.Width - point.X, (int)pictureBox2.Image.Height - point.Y); 
		}

		private void ImageSegmentation_Click(object sender, EventArgs e)
		{
			Bitmap bitmap = new Bitmap((Bitmap)pictureBox1.Image);
			//e.Graphics.DrawImage(bitmap, 60, 10);
			
			pictureBox2.Image = EditClass.applyImageSegmentation((Bitmap)pictureBox1.Image);
		}

		private void Fourier_Click(object sender, EventArgs e)
		{
			pictureBox2.Image = EditClass.applyFourierTransform((Bitmap)pictureBox1.Image);
		}

		private void Lab2ACI_Click(object sender, EventArgs e)
		{
			//Bitmap bitmap = new Bitmap((Bitmap)pictureBox1.Image);
			//pictureBox2.Image = EditClass.applySmartGrayScaling((Bitmap)pictureBox1.Image);


			Laborator2ACI_ControllForm = new Laborator2ACI(this);
			ControlClass.openChildForm(Laborator2ACI_ControllForm, activeForm, bottomPanel);
		}

		private void button12_Click(object sender, EventArgs e)
		{
			Bitmap bitmap = new Bitmap((Bitmap)pictureBox1.Image);
			pictureBox2.Image = EditClass.applySimpleGrayScaling((Bitmap)pictureBox1.Image);
		}

		private void button13_Click(object sender, EventArgs e)
		{
			//Bitmap bitmap = new Bitmap((Bitmap)pictureBox2.Image, PixelFormat.Format8bppArgb);
			//PictureBox pb = new PictureBox();
			//pb.Image = pictureBox1.Image;
			  
			//using (Bitmap large = new Bitmap(400, 400, PixelFormat.Format32bppArgb))
			//using (Graphics largeGraphics = Graphics.FromImage(large))
			//{
			//	largeGraphics.DrawImage(pb.Image, 0, 0);
			//}

			//AForge.Imaging.Filters.Grayscale filter = new AForge.Imaging.Grayscale(0.2125, 0.7154, 0.0721);
			//Bitmap grayImage = filter.Apply((Bitmap)pb.Image);

			pictureBox2.Image = EditClass.applyDebluring((Bitmap)pictureBox1.Image);
		}

		private void button14_Click(object sender, EventArgs e)
		{ 
			Bitmap bitmap = new Bitmap((Bitmap)pictureBox1.Image);
			pictureBox2.Image = EditClass.ColorToGrayscale(bitmap);
			 
		}
	}
}

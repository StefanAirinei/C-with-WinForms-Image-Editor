﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcessing
{
	public partial class Laborator2ACI : Form
	{ 
		Form1 mainForm = null;

		public Laborator2ACI()
		{
			InitializeComponent();
		} 

		public Laborator2ACI(Form1 frm) 
		{
			InitializeComponent();
			mainForm = frm;
		} 

		private void SetBrightness(object sender, EventArgs e)
		{
			String name = ((sender as TrackBar).Name);
			byte val = (byte)(sender as TrackBar).Value;  
			
			if (name == trackBar1.Name)
			{
				mainForm.changeBrightness(val, 1);
			}
			else if (name == trackBar2.Name)
			{
				mainForm.changeBrightness(val, 2);
			}
			else if (name == trackBar3.Name)
			{
				mainForm.changeBrightness(val, 3); 
			}
			else if (name == trackBar4.Name)
			{
				mainForm.changeBrightness(val, 4);
			}
		}

		public void RGB(byte val, int rgbIndex)
		{
			mainForm.pictureBox2.Image = EditClass.setRGBColor((Bitmap)mainForm.pictureBox1.Image, rgbIndex, val);
		}

		private void YUVGrayscale_Click(object sender, EventArgs e)
		{
			Bitmap srcimg = new Bitmap(mainForm.pictureBox1.Image); 

			unsafe
			{
				BitmapData bitmapData = srcimg.LockBits(new Rectangle(0, 0, srcimg.Width, srcimg.Height), ImageLockMode.ReadWrite, srcimg.PixelFormat); 

				int bytesPerPixel = Bitmap.GetPixelFormatSize(srcimg.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0; 
				 
				double G;
				double R;
				double B;
				double gamaG;
				double gamaR;
				double gamaB;
				double Gleam;
				double Y;
				double V;
				double U;
				double I;

				for (int y = 0; y < heightInPixels; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride); 

					for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						Y = 0.299 * currentLine[x + 2] + 0.587 * currentLine[x + 1] + 0.114 * currentLine[x + 0];
						U = (currentLine[x + 0] - Y) * 0.565;   //(B - Y)
						V = (currentLine[x + 2] - Y) * 0.713;   //(R - Y)
						
						R = (currentLine[x + 2] * 0.299 + currentLine[x + 2] * 0.587 + currentLine[x + 2] * 0.144) / 3;
						G = (currentLine[x + 1] * 0.299 + currentLine[x + 1] * 0.587 + currentLine[x + 1] * 0.144) / 3;
						B = (currentLine[x + 0] * 0.299 + currentLine[x + 0] * 0.587 + currentLine[x + 0] * 0.144) / 3;
						
						I = (R + G + B + (U + V)) / 4;

						currentLine[x + 2] = (byte)(4 * I);
						currentLine[x + 1] = (byte)(4 * I);
						currentLine[x + 0] = (byte)(4 * I);
					}
				}

				srcimg.UnlockBits(bitmapData); 
			}

			mainForm.pictureBox1.Image = srcimg;
		}

		int max(int a, int b, int c)
		{
			if (a >= b && a >= c)
				return a;
			else if (b >= a && b >= c)
				return b;
			else return c;
		}

		int min(int a, int b, int c)
		{
			if (a <= b && a <= c)
				return a;
			else if (b <= a && b <= c)
				return b;
			else return c;
		}

		double lightness(double value)
		{
			return value > Math.Pow((double)6 / 29, 3) ? Math.Pow(value, (double)1 / 3) : ((double)1 / 3) * Math.Pow((double)29 / 6, 2) * value + (double)4 / 29;
		}

		private void LightnessGrayscale_Click(object sender, EventArgs e)
		{
			Bitmap srcimg = new Bitmap(mainForm.pictureBox2.Image);

			unsafe
			{
				BitmapData bitmapData = srcimg.LockBits(new Rectangle(0, 0, srcimg.Width, srcimg.Height), ImageLockMode.ReadWrite, srcimg.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(srcimg.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;

				int G;
				int R;
				int B;
				double Y;
				double gamaG;
				double gamaR;
				double gamaB;
				double Gleam;
				double GLuster;
				double GLightness;

				for (int y = 0; y < heightInPixels; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						R = currentLine[x + 2];
						G = currentLine[x + 1];
						B = currentLine[x + 0];

						gamaR = Math.Pow(currentLine[x + 2], 1 / 2.2);
						gamaG = Math.Pow(currentLine[x + 1], 1 / 2.2);
						gamaB = Math.Pow(currentLine[x + 0], 1 / 2.2);

						Y = 0.2126 * R + 0.7152 * G + 0.0722 * B;

						Gleam = (gamaB + gamaG + gamaR) / 0.3f;
						GLuster = ((double)1 / (int)2) * (min(R, G, B) + max(R, G, B));
						GLightness = ((double)1 / 10) * (116 * lightness(Y) - 16);

						currentLine[x + 0] = (byte)GLightness;
						currentLine[x + 1] = (byte)GLightness;
						currentLine[x + 2] = (byte)GLightness;
					}
				}

				srcimg.UnlockBits(bitmapData);
			}

			mainForm.pictureBox2.Image = srcimg;
		}

		private void GrayscalePropriu_Click(object sender, EventArgs e)
		{
			Bitmap image = new Bitmap(mainForm.pictureBox3.Image);
			Bitmap diferenteImg = new Bitmap(image); 

			unsafe
			{
				BitmapData bitmapData = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.ReadWrite, image.PixelFormat);
				BitmapData diferenteImgData = diferenteImg.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.ReadWrite, image.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(image.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;
				byte* diferenteFirstPixel = (byte*)bitmapData.Scan0;

				for (int y = 0; y < heightInPixels -1 ; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);
					byte* diferenteCurrentLine = diferenteFirstPixel + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes - bytesPerPixel; x += bytesPerPixel)
					{
						//byte grayValue = (byte)((currentLine[x] + currentLine[x + 1] + currentLine[x + 2]) / 3);
						//byte grayValue = (byte)((currentLine[x + 2] * (float)0.2126 + currentLine[x + 1] * (float)0.7152 + currentLine[x]) * (float)0.0722);

						float eps = 0.0001f;

						float raportX =  Math.Abs(currentLine[x]  - (currentLine[x + 3] ));
						float raportY =  Math.Abs(currentLine[x]  - ((bitmapData.Stride + currentLine)[x] ));
						float raportXY = Math.Abs(currentLine[x]  - ((bitmapData.Stride + currentLine)[x + 3] ));

						//double grayMix = Math.Sqrt(raportX * raportY * raportXY);
						float grayMix = (float)(raportX + raportY + raportXY) / (int)3;

						byte grayValue = (byte)((currentLine[x] + currentLine[x + 1] + currentLine[x + 2]) / 3);

						//raportX  = (byte)Math.Sqrt((currentLine[x] - currentLine[x + 1]) * (currentLine[x] - currentLine[x + 1]));
						//raportY  = (byte)Math.Sqrt((currentLine[x] - (bitmapData.Stride + currentLine)[x]) * (currentLine[x] - (bitmapData.Stride + currentLine)[x]));
						//raportXY = (byte)Math.Sqrt((currentLine[x] - (bitmapData.Stride + currentLine)[x + 1]) * (currentLine[x] - (bitmapData.Stride + currentLine)[x + 1]));
						  
						currentLine[x + 0] = (byte)(grayValue * (grayMix / 255));
						currentLine[x + 1] = (byte)(grayValue * (grayMix / 255));
						currentLine[x + 2] = (byte)(grayValue * (grayMix / 255));

						//Console.WriteLine(grayMix);

						if (currentLine[x + 0] > 255)
						{
							currentLine[x + 0] = 255;
							currentLine[x + 1] = 255;
							currentLine[x + 2] = 255;
						}


						//diferenteCurrentLine[x] = (byte)Math.Sqrt((currentLine[x] - grayValue) * (currentLine[x] - grayValue)
						//								+ (currentLine[x + 1] - grayValue) * (currentLine[x + 1] - grayValue)
						//								+ (currentLine[x + 2] - grayValue) * (currentLine[x + 2] - grayValue));
						//
						//diferenteCurrentLine[x + 1] = diferenteCurrentLine[x + 0];
						//diferenteCurrentLine[x + 2] = diferenteCurrentLine[x + 0];

						//diferenteCurrentLine[x + 0] = (byte)Math.Sqrt((currentLine[x] - grayValue) * (currentLine[x] - grayValue) + (currentLine[x] - grayValue) * (currentLine[x] - grayValue));
						//diferenteCurrentLine[x + 1] = (byte)Math.Sqrt((currentLine[x + 1] - grayValue) * (currentLine[x + 1] - grayValue) + (currentLine[x + 1] - grayValue) * (currentLine[x + 1] - grayValue));
						//diferenteCurrentLine[x + 2] = (byte)Math.Sqrt((currentLine[x + 2] - grayValue) * (currentLine[x + 2] - grayValue) + (currentLine[x + 2] - grayValue) * (currentLine[x + 2] - grayValue));
					}
				}

				for (int y = 0; y < heightInPixels; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);
					byte* diferenteCurrentLine = diferenteFirstPixel + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						//byte grayValue = (byte)((currentLine[x] + currentLine[x + 1] + currentLine[x + 2]) / 3);	
						//byte grayValue = (byte)((currentLine[x + 2] * (float)0.2126 + currentLine[x + 1] * (float)0.7152 + currentLine[x + 0]) * (float)0.0722);
						//
						//currentLine[x + 0] = (byte)(grayValue - diferenteCurrentLine[x + 0]);
						//currentLine[x + 1] = (byte)(grayValue - diferenteCurrentLine[x + 1]);
						//currentLine[x + 2] = (byte)(grayValue - diferenteCurrentLine[x + 2]);
						//
						//if (currentLine[x + 0] > 255)
						//{
						//	currentLine[x + 0] = 255;
						//	currentLine[x + 1] = 255;
						//	currentLine[x + 2] = 255;
						//}
					}
				}

				image.UnlockBits(bitmapData);
				diferenteImg.UnlockBits(bitmapData);
			}
			 
			mainForm.pictureBox3.Image = image;
		}

		private void CGrayscale_Click(object sender, EventArgs e)
		{
			Bitmap srcimg = new Bitmap(mainForm.pictureBox4.Image);

			unsafe
			{
				BitmapData bitmapData = srcimg.LockBits(new Rectangle(0, 0, srcimg.Width, srcimg.Height), ImageLockMode.ReadWrite, srcimg.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(srcimg.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;

				int G;
				int R;
				int B;
				double Y;
				double gamaG;
				double gamaR;
				double gamaB;
				double deltaG;
				double deltaR;
				double deltaB;
				double deltaD;  // deiferente de culoare
				double D;
				double deltaY;
				double Yaxis = 0.6686;
				double concentratie;  //pierderi de contrast

				for (int y = 0; y < heightInPixels; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						R = currentLine[x + 2];
						G = currentLine[x + 1];
						B = currentLine[x + 0];

						gamaR = Math.Pow(currentLine[x + 2], (float)1 / 2.2);
						gamaG = Math.Pow(currentLine[x + 1], (float)1 / 2.2);
						gamaB = Math.Pow(currentLine[x + 0], (float)1 / 2.2);

						deltaR = R - gamaR;
						deltaG = G - gamaG;
						deltaB = B - gamaB;

						Y = 0.2126 * R + 0.7152 * G + 0.0722 * B;
						deltaD = Math.Sqrt(deltaR * deltaR + deltaG * deltaG + deltaB * deltaB);
						deltaY = Y - Math.Pow(Y, (float)1 / 2.2);

						concentratie = ((deltaD - (double)(1 / Yaxis) * Math.Abs(deltaY)) / deltaD);
						currentLine[x + 0] = (byte)(concentratie * 100);
						currentLine[x + 1] = (byte)(concentratie * 100);
						currentLine[x + 2] = (byte)(concentratie * 100);
					}
				}

				srcimg.UnlockBits(bitmapData);
			}

			mainForm.pictureBox4.Image = srcimg;
		}
	}
}

﻿namespace ImageProcessing
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        { 
			this.buttonMedianAlikeFiltre = new System.Windows.Forms.Button();
			this.buttonFile = new System.Windows.Forms.Button();
			this.buttonFiltres = new System.Windows.Forms.Button();
			this.buttonNegativeFiltre = new System.Windows.Forms.Button();
			this.lastVisiblePanel = new System.Windows.Forms.Panel();
			this.MainMenuPanel = new System.Windows.Forms.Panel();
			this.button14 = new System.Windows.Forms.Button();
			this.button13 = new System.Windows.Forms.Button();
			this.button12 = new System.Windows.Forms.Button();
			this.button11 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.filtresSubmenuPanel = new System.Windows.Forms.Panel();
			this.button10 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.FilePanel = new System.Windows.Forms.Panel();
			this.button2 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.buttonImport = new System.Windows.Forms.Button();
			this.buttonMainWorkSpace = new System.Windows.Forms.Button();
			this.buttonHome = new System.Windows.Forms.Button();
			this.logoPanel = new System.Windows.Forms.Panel();
			this.bottomPanel = new System.Windows.Forms.Panel();
			this.mainPanel = new System.Windows.Forms.Panel();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.auxMaskPicBox = new System.Windows.Forms.PictureBox();
			this.pictureBox3 = new System.Windows.Forms.PictureBox();
			this.pictureBox4 = new System.Windows.Forms.PictureBox();
			this.MainMenuPanel.SuspendLayout();
			this.filtresSubmenuPanel.SuspendLayout();
			this.FilePanel.SuspendLayout();
			this.mainPanel.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.auxMaskPicBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
			this.SuspendLayout();
			// 
			// buttonMedianAlikeFiltre
			// 
			this.buttonMedianAlikeFiltre.BackColor = System.Drawing.Color.Transparent;
			this.buttonMedianAlikeFiltre.Dock = System.Windows.Forms.DockStyle.Top;
			this.buttonMedianAlikeFiltre.FlatAppearance.BorderSize = 0;
			this.buttonMedianAlikeFiltre.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.buttonMedianAlikeFiltre.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSlateGray;
			this.buttonMedianAlikeFiltre.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
			this.buttonMedianAlikeFiltre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.buttonMedianAlikeFiltre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonMedianAlikeFiltre.ForeColor = System.Drawing.Color.DarkOrange;
			this.buttonMedianAlikeFiltre.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.buttonMedianAlikeFiltre.Location = new System.Drawing.Point(0, 30);
			this.buttonMedianAlikeFiltre.Name = "buttonMedianAlikeFiltre";
			this.buttonMedianAlikeFiltre.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
			this.buttonMedianAlikeFiltre.Size = new System.Drawing.Size(156, 24);
			this.buttonMedianAlikeFiltre.TabIndex = 4;
			this.buttonMedianAlikeFiltre.Text = "MedianFiltreAlike";
			this.buttonMedianAlikeFiltre.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.buttonMedianAlikeFiltre.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
			this.buttonMedianAlikeFiltre.UseVisualStyleBackColor = false;
			this.buttonMedianAlikeFiltre.Click += new System.EventHandler(this.MedianAlike_Click);
			// 
			// buttonFile
			// 
			this.buttonFile.Dock = System.Windows.Forms.DockStyle.Top;
			this.buttonFile.FlatAppearance.BorderSize = 0;
			this.buttonFile.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
			this.buttonFile.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
			this.buttonFile.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.buttonFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonFile.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.buttonFile.Location = new System.Drawing.Point(0, 123);
			this.buttonFile.Name = "buttonFile";
			this.buttonFile.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
			this.buttonFile.Size = new System.Drawing.Size(156, 30);
			this.buttonFile.TabIndex = 5;
			this.buttonFile.Text = "File";
			this.buttonFile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.buttonFile.UseVisualStyleBackColor = true;
			this.buttonFile.Click += new System.EventHandler(this.DisplayFilePanel_Click);
			// 
			// buttonFiltres
			// 
			this.buttonFiltres.Dock = System.Windows.Forms.DockStyle.Top;
			this.buttonFiltres.FlatAppearance.BorderSize = 0;
			this.buttonFiltres.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.buttonFiltres.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
			this.buttonFiltres.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
			this.buttonFiltres.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.buttonFiltres.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonFiltres.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.buttonFiltres.Location = new System.Drawing.Point(0, 278);
			this.buttonFiltres.Name = "buttonFiltres";
			this.buttonFiltres.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
			this.buttonFiltres.Size = new System.Drawing.Size(156, 30);
			this.buttonFiltres.TabIndex = 16;
			this.buttonFiltres.Text = "Filtres";
			this.buttonFiltres.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.buttonFiltres.UseVisualStyleBackColor = true;
			this.buttonFiltres.Click += new System.EventHandler(this.DisplayFiltresPanel_Click);
			// 
			// buttonNegativeFiltre
			// 
			this.buttonNegativeFiltre.BackColor = System.Drawing.Color.Transparent;
			this.buttonNegativeFiltre.Dock = System.Windows.Forms.DockStyle.Top;
			this.buttonNegativeFiltre.FlatAppearance.BorderSize = 0;
			this.buttonNegativeFiltre.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.buttonNegativeFiltre.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSlateGray;
			this.buttonNegativeFiltre.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
			this.buttonNegativeFiltre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.buttonNegativeFiltre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonNegativeFiltre.ForeColor = System.Drawing.Color.DarkOrange;
			this.buttonNegativeFiltre.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.buttonNegativeFiltre.Location = new System.Drawing.Point(0, 0);
			this.buttonNegativeFiltre.Name = "buttonNegativeFiltre";
			this.buttonNegativeFiltre.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
			this.buttonNegativeFiltre.Size = new System.Drawing.Size(156, 30);
			this.buttonNegativeFiltre.TabIndex = 0;
			this.buttonNegativeFiltre.Text = "Negative";
			this.buttonNegativeFiltre.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.buttonNegativeFiltre.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
			this.buttonNegativeFiltre.UseVisualStyleBackColor = false;
			this.buttonNegativeFiltre.Click += new System.EventHandler(this.NegativeFiltre_Click);
			// 
			// lastVisiblePanel
			// 
			this.lastVisiblePanel.Location = new System.Drawing.Point(0, 0);
			this.lastVisiblePanel.Name = "lastVisiblePanel";
			this.lastVisiblePanel.Size = new System.Drawing.Size(200, 100);
			this.lastVisiblePanel.TabIndex = 0;
			// 
			// MainMenuPanel
			// 
			this.MainMenuPanel.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
			this.MainMenuPanel.Controls.Add(this.button14);
			this.MainMenuPanel.Controls.Add(this.button13);
			this.MainMenuPanel.Controls.Add(this.button12);
			this.MainMenuPanel.Controls.Add(this.button11);
			this.MainMenuPanel.Controls.Add(this.button9);
			this.MainMenuPanel.Controls.Add(this.button8);
			this.MainMenuPanel.Controls.Add(this.filtresSubmenuPanel);
			this.MainMenuPanel.Controls.Add(this.buttonFiltres);
			this.MainMenuPanel.Controls.Add(this.FilePanel);
			this.MainMenuPanel.Controls.Add(this.buttonFile);
			this.MainMenuPanel.Controls.Add(this.buttonMainWorkSpace);
			this.MainMenuPanel.Controls.Add(this.buttonHome);
			this.MainMenuPanel.Controls.Add(this.logoPanel);
			this.MainMenuPanel.Dock = System.Windows.Forms.DockStyle.Left;
			this.MainMenuPanel.Location = new System.Drawing.Point(0, 0);
			this.MainMenuPanel.Name = "MainMenuPanel";
			this.MainMenuPanel.Size = new System.Drawing.Size(156, 749);
			this.MainMenuPanel.TabIndex = 17;
			// 
			// button14
			// 
			this.button14.Dock = System.Windows.Forms.DockStyle.Top;
			this.button14.FlatAppearance.BorderSize = 0;
			this.button14.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
			this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
			this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button14.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.button14.Location = new System.Drawing.Point(0, 694);
			this.button14.Name = "button14";
			this.button14.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
			this.button14.Size = new System.Drawing.Size(156, 30);
			this.button14.TabIndex = 24;
			this.button14.Text = "convert";
			this.button14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button14.UseVisualStyleBackColor = true;
			this.button14.Click += new System.EventHandler(this.button14_Click);
			// 
			// button13
			// 
			this.button13.Dock = System.Windows.Forms.DockStyle.Top;
			this.button13.FlatAppearance.BorderSize = 0;
			this.button13.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
			this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
			this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button13.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.button13.Location = new System.Drawing.Point(0, 664);
			this.button13.Name = "button13";
			this.button13.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
			this.button13.Size = new System.Drawing.Size(156, 30);
			this.button13.TabIndex = 23;
			this.button13.Text = "Deblur";
			this.button13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button13.UseVisualStyleBackColor = true;
			this.button13.Click += new System.EventHandler(this.button13_Click);
			// 
			// button12
			// 
			this.button12.Dock = System.Windows.Forms.DockStyle.Top;
			this.button12.FlatAppearance.BorderSize = 0;
			this.button12.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
			this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
			this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button12.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.button12.Location = new System.Drawing.Point(0, 634);
			this.button12.Name = "button12";
			this.button12.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
			this.button12.Size = new System.Drawing.Size(156, 30);
			this.button12.TabIndex = 22;
			this.button12.Text = "Simple Grayscale";
			this.button12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button12.UseVisualStyleBackColor = true;
			this.button12.Click += new System.EventHandler(this.button12_Click);
			// 
			// button11
			// 
			this.button11.Dock = System.Windows.Forms.DockStyle.Top;
			this.button11.FlatAppearance.BorderSize = 0;
			this.button11.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
			this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
			this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button11.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.button11.Location = new System.Drawing.Point(0, 604);
			this.button11.Name = "button11";
			this.button11.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
			this.button11.Size = new System.Drawing.Size(156, 30);
			this.button11.TabIndex = 21;
			this.button11.Text = "Laborator 2 ACI";
			this.button11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button11.UseVisualStyleBackColor = true;
			this.button11.Click += new System.EventHandler(this.Lab2ACI_Click);
			// 
			// button9
			// 
			this.button9.Dock = System.Windows.Forms.DockStyle.Top;
			this.button9.FlatAppearance.BorderSize = 0;
			this.button9.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
			this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
			this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button9.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.button9.Location = new System.Drawing.Point(0, 574);
			this.button9.Name = "button9";
			this.button9.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
			this.button9.Size = new System.Drawing.Size(156, 30);
			this.button9.TabIndex = 20;
			this.button9.Text = "Laborator 1 ACI";
			this.button9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button9.UseVisualStyleBackColor = true;
			this.button9.Click += new System.EventHandler(this.ImageSegmentation_Click);
			// 
			// button8
			// 
			this.button8.Dock = System.Windows.Forms.DockStyle.Top;
			this.button8.FlatAppearance.BorderSize = 0;
			this.button8.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
			this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
			this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button8.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.button8.Location = new System.Drawing.Point(0, 544);
			this.button8.Name = "button8";
			this.button8.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
			this.button8.Size = new System.Drawing.Size(156, 30);
			this.button8.TabIndex = 19;
			this.button8.Text = "Reset";
			this.button8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new System.EventHandler(this.reset_Click);
			// 
			// filtresSubmenuPanel
			// 
			this.filtresSubmenuPanel.BackColor = System.Drawing.Color.DimGray;
			this.filtresSubmenuPanel.Controls.Add(this.button10);
			this.filtresSubmenuPanel.Controls.Add(this.button7);
			this.filtresSubmenuPanel.Controls.Add(this.button4);
			this.filtresSubmenuPanel.Controls.Add(this.button3);
			this.filtresSubmenuPanel.Controls.Add(this.button1);
			this.filtresSubmenuPanel.Controls.Add(this.buttonMedianAlikeFiltre);
			this.filtresSubmenuPanel.Controls.Add(this.buttonNegativeFiltre);
			this.filtresSubmenuPanel.Dock = System.Windows.Forms.DockStyle.Top;
			this.filtresSubmenuPanel.ForeColor = System.Drawing.SystemColors.ButtonShadow;
			this.filtresSubmenuPanel.Location = new System.Drawing.Point(0, 308);
			this.filtresSubmenuPanel.Name = "filtresSubmenuPanel";
			this.filtresSubmenuPanel.Size = new System.Drawing.Size(156, 236);
			this.filtresSubmenuPanel.TabIndex = 6;
			// 
			// button10
			// 
			this.button10.BackColor = System.Drawing.Color.Transparent;
			this.button10.Dock = System.Windows.Forms.DockStyle.Top;
			this.button10.FlatAppearance.BorderSize = 0;
			this.button10.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSlateGray;
			this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
			this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button10.ForeColor = System.Drawing.Color.DarkOrange;
			this.button10.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.button10.Location = new System.Drawing.Point(0, 196);
			this.button10.Name = "button10";
			this.button10.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
			this.button10.Size = new System.Drawing.Size(156, 30);
			this.button10.TabIndex = 12;
			this.button10.Text = "Fourier";
			this.button10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button10.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
			this.button10.UseVisualStyleBackColor = false;
			this.button10.Click += new System.EventHandler(this.Fourier_Click);
			// 
			// button7
			// 
			this.button7.BackColor = System.Drawing.Color.Transparent;
			this.button7.Dock = System.Windows.Forms.DockStyle.Top;
			this.button7.FlatAppearance.BorderColor = System.Drawing.Color.White;
			this.button7.FlatAppearance.BorderSize = 0;
			this.button7.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSlateGray;
			this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
			this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button7.ForeColor = System.Drawing.Color.DarkOrange;
			this.button7.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.button7.Location = new System.Drawing.Point(0, 162);
			this.button7.Name = "button7";
			this.button7.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
			this.button7.Size = new System.Drawing.Size(156, 34);
			this.button7.TabIndex = 11;
			this.button7.Text = "La Place Filtre";
			this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button7.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
			this.button7.UseVisualStyleBackColor = false;
			this.button7.Click += new System.EventHandler(this.LaPlace_Click);
			// 
			// button4
			// 
			this.button4.BackColor = System.Drawing.Color.Transparent;
			this.button4.Dock = System.Windows.Forms.DockStyle.Top;
			this.button4.FlatAppearance.BorderColor = System.Drawing.Color.White;
			this.button4.FlatAppearance.BorderSize = 0;
			this.button4.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSlateGray;
			this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
			this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button4.ForeColor = System.Drawing.Color.DarkOrange;
			this.button4.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.button4.Location = new System.Drawing.Point(0, 120);
			this.button4.Name = "button4";
			this.button4.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
			this.button4.Size = new System.Drawing.Size(156, 42);
			this.button4.TabIndex = 10;
			this.button4.Text = "Overlay Picture";
			this.button4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
			this.button4.UseVisualStyleBackColor = false;
			this.button4.Click += new System.EventHandler(this.OverlayPicture_Click);
			// 
			// button3
			// 
			this.button3.BackColor = System.Drawing.Color.Transparent;
			this.button3.Dock = System.Windows.Forms.DockStyle.Top;
			this.button3.FlatAppearance.BorderColor = System.Drawing.Color.White;
			this.button3.FlatAppearance.BorderSize = 0;
			this.button3.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSlateGray;
			this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
			this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button3.ForeColor = System.Drawing.Color.DarkOrange;
			this.button3.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.button3.Location = new System.Drawing.Point(0, 84);
			this.button3.Name = "button3";
			this.button3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
			this.button3.Size = new System.Drawing.Size(156, 36);
			this.button3.TabIndex = 8;
			this.button3.Text = "Overlay Segments";
			this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
			this.button3.UseVisualStyleBackColor = false;
			this.button3.Click += new System.EventHandler(this.OverlaySegments_Click);
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.Transparent;
			this.button1.Dock = System.Windows.Forms.DockStyle.Top;
			this.button1.FlatAppearance.BorderSize = 0;
			this.button1.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSlateGray;
			this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.ForeColor = System.Drawing.Color.DarkOrange;
			this.button1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.button1.Location = new System.Drawing.Point(0, 54);
			this.button1.Name = "button1";
			this.button1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
			this.button1.Size = new System.Drawing.Size(156, 30);
			this.button1.TabIndex = 7;
			this.button1.Text = "RGB";
			this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.DisplayRGBPanel_Click);
			// 
			// FilePanel
			// 
			this.FilePanel.BackColor = System.Drawing.Color.DimGray;
			this.FilePanel.Controls.Add(this.button2);
			this.FilePanel.Controls.Add(this.button5);
			this.FilePanel.Controls.Add(this.button6);
			this.FilePanel.Controls.Add(this.buttonImport);
			this.FilePanel.Dock = System.Windows.Forms.DockStyle.Top;
			this.FilePanel.ForeColor = System.Drawing.SystemColors.ButtonShadow;
			this.FilePanel.Location = new System.Drawing.Point(0, 153);
			this.FilePanel.Name = "FilePanel";
			this.FilePanel.Size = new System.Drawing.Size(156, 125);
			this.FilePanel.TabIndex = 8;
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.Transparent;
			this.button2.Dock = System.Windows.Forms.DockStyle.Top;
			this.button2.FlatAppearance.BorderSize = 0;
			this.button2.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSlateGray;
			this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
			this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button2.ForeColor = System.Drawing.Color.DarkOrange;
			this.button2.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.button2.Location = new System.Drawing.Point(0, 90);
			this.button2.Name = "button2";
			this.button2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
			this.button2.Size = new System.Drawing.Size(156, 30);
			this.button2.TabIndex = 8;
			this.button2.Text = "Redo";
			this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
			this.button2.UseVisualStyleBackColor = false;
			// 
			// button5
			// 
			this.button5.BackColor = System.Drawing.Color.Transparent;
			this.button5.Dock = System.Windows.Forms.DockStyle.Top;
			this.button5.FlatAppearance.BorderSize = 0;
			this.button5.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSlateGray;
			this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
			this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button5.ForeColor = System.Drawing.Color.DarkOrange;
			this.button5.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.button5.Location = new System.Drawing.Point(0, 60);
			this.button5.Name = "button5";
			this.button5.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
			this.button5.Size = new System.Drawing.Size(156, 30);
			this.button5.TabIndex = 7;
			this.button5.Text = "Undo";
			this.button5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button5.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
			this.button5.UseVisualStyleBackColor = false;
			// 
			// button6
			// 
			this.button6.BackColor = System.Drawing.Color.Transparent;
			this.button6.Dock = System.Windows.Forms.DockStyle.Top;
			this.button6.FlatAppearance.BorderSize = 0;
			this.button6.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSlateGray;
			this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
			this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button6.ForeColor = System.Drawing.Color.DarkOrange;
			this.button6.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.button6.Location = new System.Drawing.Point(0, 30);
			this.button6.Name = "button6";
			this.button6.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
			this.button6.Size = new System.Drawing.Size(156, 30);
			this.button6.TabIndex = 4;
			this.button6.Text = "Export";
			this.button6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button6.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
			this.button6.UseVisualStyleBackColor = false;
			// 
			// buttonImport
			// 
			this.buttonImport.BackColor = System.Drawing.Color.Transparent;
			this.buttonImport.Dock = System.Windows.Forms.DockStyle.Top;
			this.buttonImport.FlatAppearance.BorderSize = 0;
			this.buttonImport.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
			this.buttonImport.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSlateGray;
			this.buttonImport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.LightSlateGray;
			this.buttonImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.buttonImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonImport.ForeColor = System.Drawing.Color.DarkOrange;
			this.buttonImport.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
			this.buttonImport.Location = new System.Drawing.Point(0, 0);
			this.buttonImport.Name = "buttonImport";
			this.buttonImport.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
			this.buttonImport.Size = new System.Drawing.Size(156, 30);
			this.buttonImport.TabIndex = 0;
			this.buttonImport.Text = "Import";
			this.buttonImport.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.buttonImport.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
			this.buttonImport.UseVisualStyleBackColor = false;
			this.buttonImport.Click += new System.EventHandler(this.Import_Click);
			// 
			// buttonMainWorkSpace
			// 
			this.buttonMainWorkSpace.Dock = System.Windows.Forms.DockStyle.Top;
			this.buttonMainWorkSpace.FlatAppearance.BorderSize = 0;
			this.buttonMainWorkSpace.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
			this.buttonMainWorkSpace.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
			this.buttonMainWorkSpace.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.buttonMainWorkSpace.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonMainWorkSpace.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.buttonMainWorkSpace.Location = new System.Drawing.Point(0, 93);
			this.buttonMainWorkSpace.Name = "buttonMainWorkSpace";
			this.buttonMainWorkSpace.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
			this.buttonMainWorkSpace.Size = new System.Drawing.Size(156, 30);
			this.buttonMainWorkSpace.TabIndex = 18;
			this.buttonMainWorkSpace.Text = "Main Work Space";
			this.buttonMainWorkSpace.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.buttonMainWorkSpace.UseVisualStyleBackColor = true;
			this.buttonMainWorkSpace.Click += new System.EventHandler(this.buttonMainWorkSpace_Click);
			// 
			// buttonHome
			// 
			this.buttonHome.Dock = System.Windows.Forms.DockStyle.Top;
			this.buttonHome.FlatAppearance.BorderSize = 0;
			this.buttonHome.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGoldenrod;
			this.buttonHome.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Orange;
			this.buttonHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.buttonHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.buttonHome.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
			this.buttonHome.Location = new System.Drawing.Point(0, 63);
			this.buttonHome.Name = "buttonHome";
			this.buttonHome.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
			this.buttonHome.Size = new System.Drawing.Size(156, 30);
			this.buttonHome.TabIndex = 17;
			this.buttonHome.Text = "Home";
			this.buttonHome.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.buttonHome.UseVisualStyleBackColor = true;
			this.buttonHome.Click += new System.EventHandler(this.DisplayHomePanel_Click);
			// 
			// logoPanel
			// 
			this.logoPanel.Dock = System.Windows.Forms.DockStyle.Top;
			this.logoPanel.Location = new System.Drawing.Point(0, 0);
			this.logoPanel.Name = "logoPanel";
			this.logoPanel.Size = new System.Drawing.Size(156, 63);
			this.logoPanel.TabIndex = 0;
			// 
			// bottomPanel
			// 
			this.bottomPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
			this.bottomPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.bottomPanel.ForeColor = System.Drawing.Color.Transparent;
			this.bottomPanel.Location = new System.Drawing.Point(156, 608);
			this.bottomPanel.Name = "bottomPanel";
			this.bottomPanel.Size = new System.Drawing.Size(691, 141);
			this.bottomPanel.TabIndex = 18;
			// 
			// mainPanel
			// 
			this.mainPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(23)))), ((int)(((byte)(34)))), ((int)(((byte)(32)))));
			this.mainPanel.Controls.Add(this.pictureBox4);
			this.mainPanel.Controls.Add(this.pictureBox3);
			this.mainPanel.Controls.Add(this.pictureBox2);
			this.mainPanel.Controls.Add(this.pictureBox1);
			this.mainPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.mainPanel.Location = new System.Drawing.Point(156, 0);
			this.mainPanel.Name = "mainPanel";
			this.mainPanel.Size = new System.Drawing.Size(691, 608);
			this.mainPanel.TabIndex = 19;
			this.mainPanel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.mainPanel_MouseMove);
			// 
			// pictureBox2
			// 
			this.pictureBox2.Location = new System.Drawing.Point(354, 3);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(338, 296);
			this.pictureBox2.TabIndex = 1;
			this.pictureBox2.TabStop = false;
			this.pictureBox2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseClick);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(6, 3);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(327, 296);
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// auxMaskPicBox
			// 
			this.auxMaskPicBox.Location = new System.Drawing.Point(0, 0);
			this.auxMaskPicBox.Name = "auxMaskPicBox";
			this.auxMaskPicBox.Size = new System.Drawing.Size(100, 50);
			this.auxMaskPicBox.TabIndex = 0;
			this.auxMaskPicBox.TabStop = false;
			// 
			// pictureBox3
			// 
			this.pictureBox3.Location = new System.Drawing.Point(6, 312);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new System.Drawing.Size(327, 293);
			this.pictureBox3.TabIndex = 2;
			this.pictureBox3.TabStop = false;
			// 
			// pictureBox4
			// 
			this.pictureBox4.Location = new System.Drawing.Point(354, 312);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new System.Drawing.Size(334, 293);
			this.pictureBox4.TabIndex = 3;
			this.pictureBox4.TabStop = false;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.InactiveCaption;
			this.ClientSize = new System.Drawing.Size(847, 749);
			this.Controls.Add(this.mainPanel);
			this.Controls.Add(this.bottomPanel);
			this.Controls.Add(this.MainMenuPanel);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.MainMenuPanel.ResumeLayout(false);
			this.filtresSubmenuPanel.ResumeLayout(false);
			this.FilePanel.ResumeLayout(false);
			this.mainPanel.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.auxMaskPicBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
			this.ResumeLayout(false);

		}

        #endregion
        private System.Windows.Forms.Button buttonMedianAlikeFiltre;
        private System.Windows.Forms.Button buttonFile;
		private System.Windows.Forms.Button buttonNegativeFiltre;
		private System.Windows.Forms.Button buttonFiltres;

		private System.Windows.Forms.Panel lastVisiblePanel;
		private System.Windows.Forms.Panel MainMenuPanel;
		private System.Windows.Forms.Panel logoPanel;
		private System.Windows.Forms.Panel filtresSubmenuPanel;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Panel bottomPanel;
		private System.Windows.Forms.Panel mainPanel;
		private System.Windows.Forms.Panel FilePanel;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button buttonImport;
		private System.Windows.Forms.Button button2;
		   
		private System.Windows.Forms.Button buttonHome;
		private System.Windows.Forms.Button buttonMainWorkSpace;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button4;

		public System.Windows.Forms.PictureBox auxMaskPicBox;
		private System.Windows.Forms.Button button8;
		public System.Windows.Forms.PictureBox pictureBox2;
		public System.Windows.Forms.PictureBox pictureBox1;
		public System.Windows.Forms.PictureBox pictureBox4;
		public System.Windows.Forms.PictureBox pictureBox3;

		public RGBControll_Form rgbControll_Form;
		public OverlayPicturesForm overlayPicture_Form;
		public Laborator2ACI Laborator2ACI_ControllForm;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.Button button11;
		private System.Windows.Forms.Button button12;
		private System.Windows.Forms.Button button13;
		private System.Windows.Forms.Button button14;
	}
}


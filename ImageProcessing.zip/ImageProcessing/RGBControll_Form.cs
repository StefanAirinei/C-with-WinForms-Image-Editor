﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcessing
{
	public partial class RGBControll_Form : Form
	{ 
		Form1 mainForm = null;

		public RGBControll_Form()
		{
			InitializeComponent();
		} 

		public RGBControll_Form(Form1 frm) 
		{
			InitializeComponent();
			mainForm = frm;
		} 

		private void SetRGB(object sender, EventArgs e)
		{
			String name = ((sender as TrackBar).Name);
			byte val = (byte)(sender as TrackBar).Value;  
			
			if (name == trackBar1.Name)
			{
				mainForm.RGB(val, 0);
			}
			else if (name == trackBar2.Name)
			{
				mainForm.RGB(val, 1);
			}
			else if (name == trackBar3.Name)
			{
				mainForm.RGB(val, 2); 
			}
		}

		public void RGB(byte val, int rgbIndex)
		{
			mainForm.pictureBox2.Image = EditClass.setRGBColor((Bitmap)mainForm.pictureBox1.Image, rgbIndex, val);
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcessing
{
	class MainMenuClass
	{
		public static void applyImportImage(PictureBox pictureBox1, PictureBox pictureBox2, PictureBox pictureBox3, PictureBox pictureBox4)
		{
			OpenFileDialog open = new OpenFileDialog();
			open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";

			if (open.ShowDialog() == DialogResult.OK)
			{
				// display image in picture box  
				pictureBox1.Image = new Bitmap(open.FileName);
				pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

				pictureBox2.Image = new Bitmap(open.FileName);
				pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;

				pictureBox3.Image = new Bitmap(open.FileName);
				pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;

				pictureBox4.Image = new Bitmap(open.FileName);
				pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
			} 
		}
	}
}

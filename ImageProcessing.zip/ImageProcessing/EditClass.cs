using AForge;
using AForge.Imaging.Filters;
using Emgu.CV;
using Emgu.CV.Structure;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageProcessing
{
	class EditClass
	{
		public static Image applyImageSegmentation(Bitmap bmp)
		{
			Bitmap copyGradientBMP = new Bitmap(bmp); 
			Bitmap ResultBMP = new Bitmap(bmp);
			Bitmap GxBMP = new Bitmap(bmp);    //derivata pe x
			Bitmap GyBMP = new Bitmap(bmp);    //derivata pe y
			Bitmap GBMP = new Bitmap(bmp);
			Bitmap AngleBMP = new Bitmap(bmp);

			int maxVal = 0;
			int minVal = 0;

			int val = 0;
			int valGx = 0;
			int valGy = 0;
			int valAngle = 0;
			int valMag = 0;
			int i = 0;
			int j = 0;

			float ct = 1 / 16;
			int[,] gaussianMask = {
								{ 1, 2, 1 },
								{ 2, 4, 2 },
								{ 1, 2, 1 }
							};

			int[,] GxMask = {
								{ 1, 0, -1 },
								{ 2, 0, -2 },
								{ 1, 0, -1 }
							};

			int[,] GyMask = {
								{  1,  2,  1 },
								{  0,  0,  0 },
								{ -1, -2, -1 }
							};

			unsafe
			{
				BitmapData bitmapData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);
				BitmapData bitmapDataGx = GxBMP.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);
				BitmapData bitmapDataGy = GyBMP.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);
				BitmapData bitmapDataG = GBMP.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);
				BitmapData bitmapCopyGradientBMP = copyGradientBMP.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);
				BitmapData bitmapDataAngle = AngleBMP.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(bmp.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;
				byte* FirstPixelGx = (byte*)bitmapDataGx.Scan0;
				byte* FirstPixelGy = (byte*)bitmapDataGy.Scan0;
				byte* FirstPixelG = (byte*)bitmapDataG.Scan0;
				byte* FirstPixelCopyGradient = (byte*)bitmapCopyGradientBMP.Scan0;
				byte* FirstPixelAngle = (byte*)bitmapDataG.Scan0;

				/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// apply grayscale
				for (int y = 0; y < heightInPixels; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						if (currentLine[x] > maxVal) maxVal = currentLine[x];
						if (currentLine[x] < minVal) minVal = currentLine[x];

						currentLine[x] = (byte)((currentLine[x] + currentLine[x + 1] + currentLine[x + 2]) / 3);
						currentLine[x + 1] = (byte)currentLine[x];
						currentLine[x + 2] = (byte)currentLine[x];
					}
				}
				
				//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// filtru gausian / sa reduca zgomotu
				for (int y = 1; y < heightInPixels - 1; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = bytesPerPixel; x < widthInBytes - bytesPerPixel; x += bytesPerPixel)
					{
						for (int k = y - 1; k < y + 1; k++)
						{
							byte* holdCurrentLine = FirstPixel + (k * bitmapData.Stride);

							for (int l = x - bytesPerPixel; l <= x + bytesPerPixel; l += bytesPerPixel)
							{
								val += (byte)((holdCurrentLine[l] * gaussianMask[i, j]) / 16);
								i++;
							}

							j++;
							i = 0;
						}

						currentLine[x] = (byte)val;
						currentLine[x + 1] = (byte)val;
						currentLine[x + 2] = (byte)val;

						i = 0;
						j = 0;
						val = 0;
					}
				}

				///////////////////////////////////////////////////////////////////////////////////////////////////////////////gradienti Gx Gy
				for (int y = 1; y < heightInPixels - 1; y++)
				{
					byte* currentLineGx = FirstPixelGx + (y * bitmapDataGx.Stride);
					byte* currentLineGy = FirstPixelGy + (y * bitmapDataGy.Stride);
					byte* currentLineG = FirstPixelG + (y * bitmapDataG.Stride);
					byte* currentLineCopyGradient = FirstPixelCopyGradient + (y * bitmapDataG.Stride);
					byte* currentLineAngle = FirstPixelAngle + (y * bitmapDataAngle.Stride);

					for (int x = bytesPerPixel; x < widthInBytes - bytesPerPixel; x += bytesPerPixel)
					{
						for (int k = y - 1; k < y + 1; k++)
						{
							byte* holdCurrentLineGx = FirstPixel + (k * bitmapData.Stride);
							byte* holdCurrentLineGy = FirstPixel + (k * bitmapData.Stride);
							byte* holdCurrentLineG = FirstPixelG + (k * bitmapData.Stride);
							byte* holdCurrentLineAngle = FirstPixelAngle + (k * bitmapData.Stride);

							for (int l = x - bytesPerPixel; l <= x + bytesPerPixel; l += bytesPerPixel)
							{
								valGx += (byte)((holdCurrentLineGx[l] * GxMask[i, j]));
								valGy += (byte)((holdCurrentLineGy[l] * GyMask[i, j]));
								valMag += (byte)Math.Sqrt((byte)(valGx * valGx) + (byte)(valGy * valGy));
								valAngle = (byte)((Math.Atan2((double)valGy, (double)valGx)) * (180 / Math.PI));
								i++;
							}

							j++;
							i = 0;
						}

						currentLineGx[x] = (byte)(valGx);
						currentLineGx[x + 1] = (byte)valGx;
						currentLineGx[x + 2] = (byte)valGx;
						
						currentLineGy[x] = (byte)valGy;
						currentLineGy[x + 1] = (byte)valGy;
						currentLineGy[x + 2] = (byte)valGy;

						currentLineG[x] = (byte)valMag;
						currentLineG[x + 1] = (byte)valMag;
						currentLineG[x + 2] = (byte)valMag;
						 
						currentLineCopyGradient[x] = (byte)val;
						currentLineCopyGradient[x + 1] = (byte)val;
						currentLineCopyGradient[x + 2] = (byte)val;

						currentLineAngle[x] = (byte)valAngle;
						currentLineAngle[x + 1] = (byte)valAngle;
						currentLineAngle[x + 2] = (byte)valAngle;

						i = 0;
						j = 0;
						valGx = 0;
						valGy = 0;
						valMag = 0;
						valAngle = 0;
					}
				}

				/////////////////////////////////////////////////////////////////////////////////////////////////////////interpolare
				///

				for (int y = 1; y < heightInPixels - 1; y++)
				{
					byte* currentLineG = FirstPixelG + (y * bitmapData.Stride);
					byte* currentLineAngle = FirstPixelAngle + (y * bitmapData.Stride);
					byte* currentLineResult = FirstPixel + (y * bitmapData.Stride);
					byte* currentLineCopyGradient = FirstPixelCopyGradient + (y * bitmapDataG.Stride);

					for (int x = bytesPerPixel; x < widthInBytes - bytesPerPixel; x += bytesPerPixel)
					{
						//r = alfa * b + (1 - alfa) * a
						byte a = (byte)((currentLineG - bitmapData.Stride)[x]);
						byte b = (byte)((currentLineG + bitmapData.Stride)[x]);
						 
						currentLineResult[x] = (byte)(currentLineAngle[x] * b + (1 - currentLineAngle[x]) * a);
						currentLineResult[x + 1] = (byte)(currentLineAngle[x] * b + (1 - currentLineAngle[x]) * a);
						currentLineResult[x + 2] = (byte)(currentLineAngle[x] * b + (1 - currentLineAngle[x]) * a);
						//Console.WriteLine((1 - currentLineAngle[x]));

					}
				}
				 

				///////////////////////////////////////////////////////////////////////////////////////////////////////////////thresholding
				///
				for (int y = 1; y < heightInPixels - 1; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);
				
					for (int x = bytesPerPixel; x < widthInBytes - bytesPerPixel; x += bytesPerPixel)
					{
						//if (currentLine[x] < 90)
						//{
						//	currentLine[x] = 0; 
						//	currentLine[x + 1] = 0;
						//	currentLine[x + 2] = 0;
						//}
						//
						//if (currentLine[x] > 170)
						//{
						//	currentLine[x] = 0;
						//	currentLine[x + 1] = 0;
						//	currentLine[x + 2] = 0;
						//}
					}
				}
				///////////////////////////////////////////////////////////////////////////////////////////////////////////////thresholding
				///

				int max = 0;
				int maskSize = 3;

				for (int y = maskSize; y < heightInPixels - maskSize; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = maskSize * bytesPerPixel; x < widthInBytes - maskSize * bytesPerPixel; x += bytesPerPixel)
					{
						for (int k = y - maskSize; k < y + maskSize; k++)
						{
							byte* holdCurrentLine = FirstPixel + (k * bitmapData.Stride);

							for (int l = x - maskSize * bytesPerPixel; l <= x + maskSize * bytesPerPixel; l += bytesPerPixel)
							{
								if (max < holdCurrentLine[x])
								{
									max = holdCurrentLine[x];
								}
							}
						}

						for (int k = y - maskSize; k < y + maskSize; k++)
						{
							byte* holdCurrentLine = FirstPixel + (k * bitmapData.Stride);

							byte someColor = 40;

							for (int l = x - maskSize * bytesPerPixel; l <= x + maskSize * bytesPerPixel; l += bytesPerPixel)
							{
								if (max > holdCurrentLine[x])
								{
									holdCurrentLine[x] = someColor;
									holdCurrentLine[x + 1] = someColor;
									holdCurrentLine[x + 2] = someColor;
								}
								else
								{
									holdCurrentLine[x] = (byte)max;
									holdCurrentLine[x + 1] = (byte)max;
									holdCurrentLine[x + 2] = (byte)max;
								}
							}
						}

						max = 0;
					}
				}

				////////////////////////////////////////////////////////////////////////////////////////////////////////////////aplic un filtru ca sa fac sectiuni separate in functie de medie
				///

				int maskAvgSize = 4;
				int medie = 0;

				for (int y = maskAvgSize; y < heightInPixels - maskAvgSize; y += maskAvgSize)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = maskAvgSize * bytesPerPixel; x < widthInBytes - maskAvgSize * bytesPerPixel; x += maskAvgSize * bytesPerPixel)
					{
						//for (int k = y - maskAvgSize; k < y + maskAvgSize; k++)
						//{
						//	byte* holdCurrentLine = FirstPixel + (k * bitmapData.Stride);
						//
						//	for (int l = x - maskAvgSize * bytesPerPixel; l <= x + maskAvgSize * bytesPerPixel; l += bytesPerPixel)
						//	{
						//		medie += (byte)(holdCurrentLine[l] / ((2 * maskAvgSize + 1) * (2 * maskAvgSize + 1)));
						//	}
						//}

						//for (int k = y - maskAvgSize; k < y + maskAvgSize; k++)
						{
							byte* holdCurrentLine = FirstPixel + (y * bitmapData.Stride);
						
							for (int l = x - maskAvgSize * bytesPerPixel; l <= x + maskAvgSize * bytesPerPixel; l += bytesPerPixel)
							{ 
								medie += (byte)(holdCurrentLine[l] / ((2 * maskAvgSize + 1)));
							}
						}

						//or (int k = y - maskAvgSize; k < y + maskAvgSize; k++)
						{
							byte* holdCurrentLine = FirstPixel + (y * bitmapData.Stride);

							for (int l = x - maskAvgSize * bytesPerPixel; l <= x + maskAvgSize * bytesPerPixel; l += bytesPerPixel)
							{
								if (medie < 22)
								{
									//currentLine[l] = (byte)0;
									//currentLine[l + 1] = (byte)0;
									//currentLine[l + 2] = (byte)0;
								}
							}
						}
						 
						medie = 0;

						for (int k = y - maskAvgSize; k < y + maskAvgSize; k++)
						{
							byte* holdCurrentLine = FirstPixel + (k * bitmapData.Stride);
						
							for (int l = x - maskAvgSize * bytesPerPixel; l <= x + maskAvgSize * bytesPerPixel; l += bytesPerPixel)
							{
								medie += (byte)(holdCurrentLine[l] / ((2 * maskAvgSize + 1) * (2 * maskAvgSize + 1)));
							}
						}

						for (int k = y - maskAvgSize; k < y + maskAvgSize; k++)
						{
							byte* holdCurrentLine = FirstPixel + (k * bitmapData.Stride);

							for (int l = x - maskAvgSize * bytesPerPixel; l <= x + maskAvgSize * bytesPerPixel; l += bytesPerPixel)
							{
								if (medie > 15)
								{
									holdCurrentLine[l] = (byte)0;
									holdCurrentLine[l + 1] = (byte)0;
									holdCurrentLine[l + 2] = (byte)0;
								}
							}
						}

						medie = 0;

					}
				}


				//int pipi = 15; 
				//for (int y = 1; y < heightInPixels - 1; y++)
				//{
				//	byte* currentLine = FirstPixel + (y * bitmapData.Stride);
				//
				//	for (int x =  bytesPerPixel; x < widthInBytes - pipi * bytesPerPixel; x += bytesPerPixel)
				//	{		
				//		if (currentLine[x] - currentLine[x + 4 * pipi] < 0 || currentLine[x] - currentLine[x + 4 * pipi] > 180)
				//		{
				//			currentLine[x] = (byte)255;
				//			currentLine[x + 1] = (byte)255;
				//			currentLine[x + 2] = (byte)255;
				//		}
				//		else
				//		{
				//			currentLine[x] = (byte) 0;
				//			currentLine[x + 1] = (byte) 0;
				//			currentLine[x + 2] = (byte) 0;
				//		}
				//	}
				//}

				bmp.UnlockBits(bitmapData);
				GxBMP.UnlockBits(bitmapDataGx);
				GyBMP.UnlockBits(bitmapDataGy);
				GBMP.UnlockBits(bitmapDataG);
				AngleBMP.UnlockBits(bitmapDataAngle);
				copyGradientBMP.UnlockBits(bitmapCopyGradientBMP);
			}

			return bmp;
		}

		internal static Image applySimpleGrayScaling(Bitmap bmp)
		{ 
			unsafe
			{
				Grayscale g;
				BitmapData bitmapData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(bmp.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;

				for (int y = 0; y < heightInPixels; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						//byte grayValue = (byte)((currentLine[x] * (float)0.2126 + currentLine[x + 1] * (float)0.7152 + currentLine[x + 2]) * (float)0.0722);
						byte grayValue = (byte)((currentLine[x]  + currentLine[x + 1]   + currentLine[x + 2]) / 3);
						currentLine[x + 0] = (byte)(1 *grayValue);
						currentLine[x + 1] = (byte)(1 *grayValue);
						currentLine[x + 2] = (byte)(1 *grayValue);
					}
				}
				 
				bmp.UnlockBits(bitmapData);
			}

			return bmp;
		}

		internal static Image applyDebluring(Bitmap bmp)
		{

			////Mat img = imread("blur.JPG", 0);
			//Mat originalImg;
			//
			//Mat dftInput1, dftImage1, inverseDFT, inverseDFTconverted, inverseDFTconvertedResized, imgResized;
			//originalImg.convertTo(dftInput1, CV_32F);
			//dft(dftInput1, dftImage1, DFT_COMPLEX_OUTPUT);
			//
			////applyWienerFiltre(dftImage1);
			//applySecondModelFiltre(dftImage1);
			//Image<Bgr, byte> source = new Image<Bgr, byte>(bmp); //Image Class from Emgu.CV
			//Mat mat = imageCV.Mat;
			//bmp = intent.getExtras().get("data");
			//ByteArrayOutputStream stream = new ByteArrayOutputStream();
			//bmp.compress(Bitmap.CompressFormat.PNG, 100, stream);
			//byte[] byteArray = stream.toByteArray();
			//bmp.recycle();
			//
			//Emgu.CV.CvInvoke.Dft(byteArray, a, 1, 0);
			//
			//return null;

			//AForge.Imaging.Filters.Grayscale filter = new AForge.Imaging.Grayscale(0.2125, 0.7154, 0.0721);
			//Bitmap grayImage = filter.Apply(newImg);

			//var bmp8bpp = Grayscale.CommonAlgorithms.BT709.Apply(bmp);
			//Bitmap newImg = new Bitmap(bmp, new Size(400, 400));
			//ResizeBilinear filter = new ResizeBilinear(400, 400);
			//// apply the filter
			//bmp = filter.Apply(bmp);
			//
			//AForge.Imaging.ComplexImage cimage = AForge.Imaging.ComplexImage.FromBitmap(bmp); 
			//cimage.ForwardFourierTransform(); 
			//System.Drawing.Bitmap img = cimage.ToBitmap();
			//
			return bmp;
		}


		internal static Image applySmartGrayScaling(Bitmap image)
		{
			Bitmap diferenteImg = new Bitmap(image);

			unsafe
			{
				BitmapData bitmapData = image.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.ReadWrite, image.PixelFormat);
				BitmapData diferenteImgData = diferenteImg.LockBits(new Rectangle(0, 0, image.Width, image.Height), ImageLockMode.ReadWrite, image.PixelFormat);
		
				int bytesPerPixel = Bitmap.GetPixelFormatSize(image.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;
				byte* diferenteFirstPixel = (byte*)bitmapData.Scan0;

				//for (int y = 0; y < heightInPixels; y++)
				//{
				//	byte* currentLine = FirstPixel + (y * bitmapData.Stride);
				//	byte* diferenteCurrentLine = diferenteFirstPixel + (y * bitmapData.Stride);
				//
				//	for (int x = 0; x < widthInBytes; x += bytesPerPixel)
				//	{
				//		//byte grayValue = (byte)((currentLine[x] + currentLine[x + 1] + currentLine[x + 2]) / 3);
				//		byte grayValue = (byte)((currentLine[x + 2] * (float)0.2126 + currentLine[x + 1] * (float)0.7152 + currentLine[x]) * (float)0.0722);
				//		
				//		diferenteCurrentLine[x] = (byte)Math.Sqrt((currentLine[x] - grayValue) * (currentLine[x] - grayValue) 
				//										+ (currentLine[x + 1] - grayValue) * (currentLine[x + 1] - grayValue)
				//										+ (currentLine[x + 2] - grayValue) * (currentLine[x + 2] - grayValue));
				//		
				//		diferenteCurrentLine[x + 1] = diferenteCurrentLine[x + 0];
				//		diferenteCurrentLine[x + 2] = diferenteCurrentLine[x + 0];
				//		
				//		//diferenteCurrentLine[x + 0] = (byte)Math.Sqrt((currentLine[x] - grayValue) * (currentLine[x] - grayValue) + (currentLine[x] - grayValue) * (currentLine[x] - grayValue));
				//		//diferenteCurrentLine[x + 1] = (byte)Math.Sqrt((currentLine[x + 1] - grayValue) * (currentLine[x + 1] - grayValue) + (currentLine[x + 1] - grayValue) * (currentLine[x + 1] - grayValue));
				//		//diferenteCurrentLine[x + 2] = (byte)Math.Sqrt((currentLine[x + 2] - grayValue) * (currentLine[x + 2] - grayValue) + (currentLine[x + 2] - grayValue) * (currentLine[x + 2] - grayValue));
				//	 
				//	}
				//}

				//for (int y = 0; y < heightInPixels; y++)
				//{
				//	byte* currentLine = FirstPixel + (y * bitmapData.Stride);
				//	byte* diferenteCurrentLine = diferenteFirstPixel + (y * bitmapData.Stride);
				//
				//	for (int x = 0; x < widthInBytes; x += bytesPerPixel)
				//	{
				//		//currentLine[x + 0] = (byte)(currentLine[x + 0]);
				//		//currentLine[x + 1] = (byte)(currentLine[x + 1]);
				//		//currentLine[x + 2] = (byte)(currentLine[x + 2]);
				//		//byte grayValue = (byte)((currentLine[x] + currentLine[x + 1] + currentLine[x + 2]) / 3);
				//		byte grayValue = (byte)((currentLine[x + 2] * (float)0.2126 + currentLine[x + 1] * (float)0.7152 + currentLine[x + 0]) * (float)0.0722);
				//
				//		currentLine[x + 0] = (byte)(grayValue  - diferenteCurrentLine[x + 0] * 1.1);
				//		currentLine[x + 1] = (byte)(grayValue  - diferenteCurrentLine[x + 1] * 1.1);
				//		currentLine[x + 2] = (byte)(grayValue  - diferenteCurrentLine[x + 2] * 1.1);
				//
				//		if (currentLine[x + 0] > 255) 
				//		{
				//			currentLine[x + 0] = 255;
				//			currentLine[x + 1] = 255;
				//			currentLine[x + 2] = 255;
				//		}
				//	}
				//}


				///////////////////////////////////////   cea mai ok de pana acum, combinatii de YUV RGB
				///

				//double Y;
				//double U;
				//double V;
				//double UV;
				//double G;
				//double R;
				//double B;
				//double I;
				//
				//for (int y = 0; y < heightInPixels; y++)
				//{
				//	byte* currentLine = FirstPixel + (y * bitmapData.Stride);
				//
				//	for (int x = 0; x < widthInBytes; x += bytesPerPixel)
				//	{
				//		Y = 0.299 * currentLine[x + 2] + 0.587 * currentLine[x + 1] + 0.114 * currentLine[x + 0];
				//	
				//		U = (currentLine[x + 0] - Y) * 0.565;   //(B - Y)
				//		V = (currentLine[x + 2] - Y) * 0.713;   //(R - Y)
				//
				//		R = (currentLine[x + 2] * 0.299 + currentLine[x + 2] * 0.587 + currentLine[x + 2] * 0.144) / 3;
				//		G = (currentLine[x + 1] * 0.299 + currentLine[x + 1] * 0.587 + currentLine[x + 1] * 0.144) / 3;
				//		B = (currentLine[x + 0] * 0.299 + currentLine[x + 0] * 0.587 + currentLine[x + 0] * 0.144) / 3;
				//
				//		I = (R + G + B + (U + V)) / 4;
				//
				//		currentLine[x + 2] = (byte)(4 * I);
				//		currentLine[x + 1] = (byte)(4 * I);
				//		currentLine[x + 0] = (byte)(4 * I);
				//	}
				//}
				//
				//image.UnlockBits(bitmapData);
				//diferenteImg.UnlockBits(bitmapData);


				/////////////////////////////////////
				double G;
				double R;
				double B;
				double gamaG;
				double gamaR;
				double gamaB;
				double Gleam;

				for (int y = 0; y < heightInPixels; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						gamaR = Math.Pow(currentLine[x + 2], 1 / 2.2);
						gamaG = Math.Pow(currentLine[x + 1], 1 / 2.2);
						gamaB = Math.Pow(currentLine[x + 0], 1 / 2.2);

						Gleam = (gamaB + gamaG + gamaR) / 0.3f;

						currentLine[x + 0] = (byte)Gleam;
						currentLine[x + 1] = (byte)Gleam;
						currentLine[x + 2] = (byte)Gleam;
					}
				}

				image.UnlockBits(bitmapData);
				diferenteImg.UnlockBits(bitmapData);
			}

			return image;
		}

		public static Image applyMedianAlikeFiltre(Bitmap bmp)
		{
			int valR = 0;
			int valG = 0;
			int valB = 0;

			unsafe
			{
				BitmapData bitmapData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(bmp.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;

				int filtreSizeLength = 3;   ////scad o unitate ca altfel as avea filtru de 6 * 6, pixelu initial nu intra in dimensiune
				int filtreSize = (filtreSizeLength + 1) * (filtreSizeLength + 1);

				//Parallel.For(1, heightInPixels - 2, y => 
				for (int y = 0; y < heightInPixels - filtreSizeLength; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes - filtreSizeLength * bytesPerPixel; x += bytesPerPixel)
					//for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						for (byte* holdCurrentLine = currentLine; holdCurrentLine <= currentLine + filtreSizeLength * bitmapData.Stride; holdCurrentLine += bitmapData.Stride)
						{
							for (int l = x; l <= x + filtreSizeLength * bytesPerPixel; l += bytesPerPixel)
							{
								valR += (byte)holdCurrentLine[l] / filtreSize;      //se face o medie a pixelilor vecini
								valG += (byte)holdCurrentLine[l + 1] / filtreSize;
								valB += (byte)holdCurrentLine[l + 2] / filtreSize;
							}
						}

						currentLine[x] = (byte)valR;
						currentLine[x + 1] = (byte)valG;
						currentLine[x + 2] = (byte)valB;

						valR = 0;
						valG = 0;
						valB = 0;
					}
				}
				//);

				bmp.UnlockBits(bitmapData);
			}

			return bmp;
		}

		public static Image setGrayscaleBrightness(Bitmap bmp, int trackIndex, int val)
		{
			unsafe
			{
				BitmapData bitmapData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(bmp.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;

				double R;
				double G;
				double B;

				for (int y = 0; y < heightInPixels; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						if (val > 1)
						{
							R = currentLine[x + 2];
							R *= ((double)val / 100);

							G = currentLine[x + 1];
							G *= ((double)val / 100);

							B = currentLine[x + 0];
							B *= ((double)val / 100);

							currentLine[x + 0] = (byte)R;
							currentLine[x + 1] = (byte)G;
							currentLine[x + 2] = (byte)B;
						}
						else if (val < -100)
						{
							R = currentLine[x + 2];
							R /= ((double)val / 100);

							G = currentLine[x + 1];
							G /= ((double)val / 100);

							B = currentLine[x + 0];
							B /= ((double)val / 100);

							currentLine[x + 0] = (byte)R;
							currentLine[x + 1] = (byte)G;
							currentLine[x + 2] = (byte)B;
						}

						if (currentLine[x] > (byte)255)
						{
							currentLine[x + 0] = 255;
							currentLine[x + 1] = 255;
							currentLine[x + 2] = 255;
						}
						else if (currentLine[x] < (byte)0)
						{
							currentLine[x + 0] = 0;
							currentLine[x + 1] = 0;
							currentLine[x + 2] = 0;
						}
					}
				}

				bmp.UnlockBits(bitmapData);
			}

			return bmp;
		}

		public static Image setRGBColor(Bitmap bmp, int rgbIndex, byte val)
		{
			unsafe
			{
				BitmapData bitmapData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(bmp.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;

				for (int y = 0; y < heightInPixels; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						if ((currentLine[x + rgbIndex] = val) > (byte)255)
							currentLine[x + rgbIndex] = 255;
					}
				}

				bmp.UnlockBits(bitmapData);
			}

			return bmp;
		}

		public static Image applySlowMedianFiltre(Bitmap bmp)
		{
			int valR = 0;
            int valG = 0;
            int valB = 0;

            Bitmap img = new Bitmap(bmp);
            Bitmap imgResult = new Bitmap(bmp); 

            try
            {
                for (int u = 1; u < img.Width - 1; u++) // se parcurge imaginea
                {
                    for (int v = 1; v < img.Height - 1; v++)
                    {
                        for (int k = u - 1; k <= u + 1; k++)
                        {
                            for (int l = v - 1; l <= v + 1; l++)
                            {
                                Color pixelColor = img.GetPixel(k, l);

                                valR += pixelColor.R / 9;      //se face omedie a pixelilor vecini
                                valG += pixelColor.G / 9;
                                valB += pixelColor.B / 9;
                            }
                        }

                        //valG = valB >> 1;

                        Color newColor = Color.FromArgb((byte)valR, (byte)valG, (byte)valB);
                        imgResult.SetPixel(u, v, newColor); 

                        valR = 0;
                        valG = 0;
                        valB = 0;
                    }
                }

                return imgResult;
            }
            catch (ArgumentException)
            {
                MessageBox.Show("There was an error." +
                    "Check the path to the image file.");
            }
			return bmp;
		}
		
		public static unsafe void applyNegative(byte *r, byte *g, byte *b)
		{
			//*r = (byte)(255 - *r);
			//*g = (byte)(255 - *g);
			//*b = (byte)(255 - *b);

			*r = (byte)(*r + 6 * Math.Tan(*r) * Math.Tan(*r));
			*g = (byte)(*g + 6 * Math.Tan(*g) * Math.Tan(*g));
			*b = (byte)(*b + 6 * Math.Tan(*b) * Math.Tan(*b));
		}

		public static Image applyFiltre(Bitmap bmp)
		{
			unsafe
			{
				BitmapData bitmapData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(bmp.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;

				for (int y = 0; y < heightInPixels; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);

					for (int x = 0; x < widthInBytes; x += bytesPerPixel)
					{
						applyNegative(&currentLine[x], &currentLine[x + 1], &currentLine[x + 2]);
					}
				}

				bmp.UnlockBits(bitmapData);
			}

			return bmp;
		}

		public static Image overlayPicture(Bitmap bmp, Bitmap bmpMaskPic)
		{ 
			//Bitmap bmp = new Bitmap(pictureBox2.Image);
			//Bitmap bmpMaskPic = new Bitmap(mask);

			if (bmp == null || bmpMaskPic == null)
				return null;

			unsafe
			{
				BitmapData bitmapData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);
				BitmapData bitmapDataMaskPic = bmpMaskPic.LockBits(new Rectangle(0, 0, bmpMaskPic.Width, bmpMaskPic.Height), ImageLockMode.ReadWrite, bmpMaskPic.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(bmp.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				int bytesPerPixel_MaskPic = Bitmap.GetPixelFormatSize(bmpMaskPic.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels_MaskPic = bitmapDataMaskPic.Height;
				int widthInBytes_MaskPic = bitmapDataMaskPic.Width * bytesPerPixel_MaskPic;

				byte* FirstPixel = (byte*)bitmapData.Scan0;
				byte* FirstPixelMask = (byte*)bitmapDataMaskPic.Scan0;

				byte r = 0;
				byte g = 0;
				byte b = 0;

				//Parallel.For(0, heightInPixels, Y =>

				int height = Math.Min(heightInPixels, heightInPixels_MaskPic);
				int width = Math.Min(widthInBytes, widthInBytes_MaskPic);

				for (int y = 0; y < height; y++)
				{
					byte* currentLine = FirstPixel + (y * bitmapData.Stride);
					byte* currentLine_MaskPic = FirstPixelMask + (y * bitmapDataMaskPic.Stride);

					for (int x = 0; x < width; x += bytesPerPixel)
					{
						currentLine[x] = (byte)((currentLine[x] + currentLine_MaskPic[x]) / 2);
						currentLine[x + 1] = (byte)((currentLine[x + 1] + currentLine_MaskPic[x + 1]) / 2);
						currentLine[x + 2] = (byte)((currentLine[x + 2] + currentLine_MaskPic[x + 2]) / 2);
					}
				}

				bmpMaskPic.UnlockBits(bitmapDataMaskPic);
				bmp.UnlockBits(bitmapData);
			}

			return bmp;
		}

		public static void ImportMaskPicture(PictureBox pictureBox3)    //asta i masca
		{
			OpenFileDialog open = new OpenFileDialog();
			open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";

			if (open.ShowDialog() == DialogResult.OK)
			{
				// display image in picture box  
				pictureBox3.Image = new Bitmap(open.FileName);
				pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
			}
		}

		public static Image applyFourierTransform(Bitmap bmp)
		{
			if (bmp == null)
				return null;
				
			Bitmap bmpNew = new Bitmap(bmp);

			unsafe
			{
				BitmapData bitmapData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);
				BitmapData bitmapDataNew = bmpNew.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmpNew.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(bmp.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;

				byte r = 0;
				byte g = 0;
				byte b = 0;

				for (int Y = 0; Y < heightInPixels; Y++)
				//Parallel.For(0, heightInPixels, Y =>
				{
					byte* CurrentLine = FirstPixel + (Y * bitmapDataNew.Stride);

					for (int X = 0; X < widthInBytes; X += bytesPerPixel)
					{
						for (int y = 0; y < heightInPixels; y++)
						{
							byte* currentLine = FirstPixel + (y * bitmapData.Stride);

							for (int x = 0; x < widthInBytes; x += bytesPerPixel)
							{
								//byte pi = (byte)(2 * Math.PI * Math.Cos(x * X / heightInPixels + y * Y / widthInBytes));
								byte pi = (byte)(2 * Math.PI * Math.Cos(x * X / heightInPixels + y * Y / widthInBytes));

								r = (byte)(currentLine[x] * pi);
								//g = (byte)(currentLine[x + 1] * pi);
								//b = (byte)(currentLine[x + 2] * pi);
							}
						}
						
						CurrentLine[X] = r;
						CurrentLine[X + 2] = r;
						CurrentLine[X + 1] = r;
					}
				}//);

				bmpNew.UnlockBits(bitmapDataNew);
				bmp.UnlockBits(bitmapData);
			}
			 
			return bmp;
		}

		public static Image applyOverlaySegments(Bitmap bmp)
		{
			List<KeyValuePair<int, int>>[] myList = new List<KeyValuePair<int, int>>[7];

			for (int i = 0; i < 7; i++)
			{
				myList[i] = new List<KeyValuePair<int, int>>();
			}
			  
			KeyValuePair<int, int>[] myVertices = new KeyValuePair<int, int>[]
			{
				new KeyValuePair<int, int>(100 / 5, 100 / 5),
				new KeyValuePair<int, int>(100 / 5, 200 / 5),
				new KeyValuePair<int, int>(200 / 5, 100 / 5),
				new KeyValuePair<int, int>(200 / 5, 200 / 5),
				new KeyValuePair<int, int>(150 / 5, 150 / 5),
				new KeyValuePair<int, int>(150 / 5, 300 / 5),
				new KeyValuePair<int, int>(300 / 5, 150 / 5),
				new KeyValuePair<int, int>(300 / 5, 300 / 5)
			};

			{
				List<KeyValuePair<int, int>> p = new List<KeyValuePair<int, int>>();
				p.Add(myVertices[1]);
				p.Add(myVertices[2]);
				myList[0] = new List<KeyValuePair<int, int>>(p);
				p.Clear();

				p.Add(myVertices[0]);
				p.Add(myVertices[4]);
				myList[1] = new List<KeyValuePair<int, int>>(p);
				p.Clear();

				p.Add(myVertices[0]);
				p.Add(myVertices[3]);
				myList[2] = new List<KeyValuePair<int, int>>(p);
				p.Clear();

				p.Add(myVertices[2]);
				p.Add(myVertices[4]);
				myList[3] = new List<KeyValuePair<int, int>>(p);
				p.Clear();

				p.Add(myVertices[1]);
				p.Add(myVertices[3]);
				p.Add(myVertices[4]);
				myList[4] = new List<KeyValuePair<int, int>>(p);
				p.Clear();

				p.Add(myVertices[4]);
				p.Add(myVertices[7]);
				myList[5] = new List<KeyValuePair<int, int>>(p);
				p.Clear();

				p.Add(myVertices[5]);
				p.Add(myVertices[6]);
				myList[6] = new List<KeyValuePair<int, int>>(p);
				p.Clear();
			}

			unsafe
			{
				BitmapData bitmapData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadWrite, bmp.PixelFormat);

				int bytesPerPixel = Bitmap.GetPixelFormatSize(bmp.PixelFormat) / 8;     //adancimea in octeti (3 octeti);
				int heightInPixels = bitmapData.Height;
				int widthInBytes = bitmapData.Width * bytesPerPixel;

				byte* FirstPixel = (byte*)bitmapData.Scan0;

				for (int i = 0; i < myList.Length; i++)
				{
					if (myList[i].Count == 1)
						return null;

					for (int y = myList[i][0].Key; y < myList[i][1].Key; y++)
					{
						byte* currentLine = FirstPixel + (y * bitmapData.Stride);

						for (int x = myList[i][0].Value * bytesPerPixel; x < myList[i][1].Value * bytesPerPixel; x += bytesPerPixel)
						{
							currentLine[x] = (byte)0;
							currentLine[x + 1] = (byte)0;
							currentLine[x + 2] = (byte)0;
						}
					}
				}

				bmp.UnlockBits(bitmapData);
			}

			return bmp;
		}

		public static int laPlace(Bitmap bmp, BitmapData ImageData, byte[] buffer, int x, int y, int glid, int rgb)
		{
			int val = 0;

			int[,] filter = {
								{ 1,  3, 1 },
								{ 3, -5, 3 },
								{ 1,  3, 1 }
							};

			for (int yy = -glid, i = 0; yy <= glid && i < 3; yy++, i++)
			{ 
				for (int xx = -glid * 3, j = 0; xx <= glid * 3 && j < 3; xx += 3, j++)
				{
					int innerLocation = x + xx + (yy + y) * ImageData.Stride; //to get the location of any pixel >> location = x + y * Stride
					
					val += buffer[innerLocation + rgb] * filter[i, j];
				} 
			}

			return val;
		}

		public static Image applyLaPlaceFiltre(Bitmap bmp)
		{
			Bitmap bmpNew = new Bitmap(bmp);
			BitmapData ImageData, ImageData2;
			byte[] buffer, buffer2;
			int location, glid;
			IntPtr pointer, pointer2;

			unsafe
			{
				ImageData = bmp.LockBits(new Rectangle(0, 0, bmp.Width, bmp.Height), ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
				ImageData2 = bmpNew.LockBits(new Rectangle(0, 0, bmpNew.Width, bmpNew.Height), ImageLockMode.WriteOnly, PixelFormat.Format24bppRgb);
				
				buffer = new byte[ImageData.Stride * bmp.Height];
				buffer2 = new byte[ImageData.Stride * bmp.Height];
				
				pointer = ImageData.Scan0;
				pointer2 = ImageData2.Scan0;
			
				Marshal.Copy(pointer, buffer, 0, buffer.Length);

				glid = 1;

				for (int y = 3; y < bmp.Height - 3; y++) //Same idea you need to watch sharp by c# video first
				{
					for (int x = 3; x < bmp.Width * 3 - 3; x += 3)
					{
						location = x + y * ImageData.Stride;

						//to get the location of any pixel >> location = x + y * Stride
						 
						buffer2[location + 0] = (byte)(laPlace(bmp, ImageData, buffer, x, y, glid, 0) );
						buffer2[location + 1] = (byte)(laPlace(bmp, ImageData, buffer, x, y, glid, 1) );
						buffer2[location + 2] = (byte)(laPlace(bmp, ImageData, buffer, x, y, glid, 2) );
					}
				}

				Marshal.Copy(buffer2, 0, pointer2, buffer.Length);

				bmp.UnlockBits(ImageData);
				bmpNew.UnlockBits(ImageData2);
			}

			return bmpNew;
		}

		public static Bitmap ColorToGrayscale(Bitmap bmp)
		{
			int w = bmp.Width,
			h = bmp.Height,
			r, ic, oc, bmpStride, outputStride, bytesPerPixel;
			PixelFormat pfIn = bmp.PixelFormat;
			ColorPalette palette;
			Bitmap output;
			BitmapData bmpData, outputData;

			//Create the new bitmap
			output = new Bitmap(w, h, PixelFormat.Format8bppIndexed);

			//Build a grayscale color Palette
			palette = output.Palette;
			for (int i = 0; i < 256; i++)
			{
				Color tmp = Color.FromArgb(255, i, i, i);
				palette.Entries[i] = Color.FromArgb(255, i, i, i);
			}
			output.Palette = palette;

			//No need to convert formats if already in 8 bit
			if (pfIn == PixelFormat.Format8bppIndexed)
			{
				output = (Bitmap)bmp.Clone();

				//Make sure the palette is a grayscale palette and not some other
				//8-bit indexed palette
				output.Palette = palette;

				return output;
			}

			//Get the number of bytes per pixel
			switch (pfIn)
			{
				case PixelFormat.Format24bppRgb: bytesPerPixel = 3; break;
				case PixelFormat.Format32bppArgb: bytesPerPixel = 4; break;
				case PixelFormat.Format32bppRgb: bytesPerPixel = 4; break;
				default: throw new InvalidOperationException("Image format not supported");
			}

			//Lock the images
			bmpData = bmp.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.ReadOnly,
			pfIn);
			outputData = output.LockBits(new Rectangle(0, 0, w, h), ImageLockMode.WriteOnly,
			PixelFormat.Format8bppIndexed);
			bmpStride = bmpData.Stride;
			outputStride = outputData.Stride;

			//Traverse each pixel of the image
			unsafe
			{
				byte* bmpPtr = (byte*)bmpData.Scan0.ToPointer(),
				outputPtr = (byte*)outputData.Scan0.ToPointer();

				if (bytesPerPixel == 3)
				{
					//Convert the pixel to it's luminance using the formula:
					// L = .299*R + .587*G + .114*B
					//Note that ic is the input column and oc is the output column
					for (r = 0; r < h; r++)
						for (ic = oc = 0; oc < w; ic += 3, ++oc)
							outputPtr[r * outputStride + oc] = (byte)(int)
							(0.299f * bmpPtr[r * bmpStride + ic] +
							0.587f * bmpPtr[r * bmpStride + ic + 1] +
							0.114f * bmpPtr[r * bmpStride + ic + 2]);
				}
				else //bytesPerPixel == 4
				{
					//Convert the pixel to it's luminance using the formula:
					// L = alpha * (.299*R + .587*G + .114*B)
					//Note that ic is the input column and oc is the output column
					for (r = 0; r < h; r++)
						for (ic = oc = 0; oc < w; ic += 4, ++oc)
							outputPtr[r * outputStride + oc] = (byte)(int)
							((bmpPtr[r * bmpStride + ic] / 255.0f) *
							(0.299f * bmpPtr[r * bmpStride + ic + 1] +
							0.587f * bmpPtr[r * bmpStride + ic + 2] +
							0.114f * bmpPtr[r * bmpStride + ic + 3]));
				}
			}

			//Unlock the images
			bmp.UnlockBits(bmpData);
			output.UnlockBits(outputData);

			return output;
		}
	}
}
